import torch,json
from pathlib import Path
from baseline_inference.foveal_engine import FovealLLM
from benchmarks.verify_foveal_cache import reference_logits,comparison
import foveal_cpt.attention as fa
root=Path('benchmarks/logs/foveal_verified/checkpoint_root.txt').read_text().strip()
e=FovealLLM(root+'/polar/lm_output_kl/cpt',device='cuda');e.model.float()
fa.HAS_POLAR_TRITON=False;fa.HAS_FLEX_ATTENTION=False
for b in e.model.blocks:
 if hasattr(b.attn,'base'):b.attn.base.mem.kernel='torch'
text='\n'.join(f'Record {i}: the parcel marked {i*71+19} is in room {i%17}. The earlier record names a different room. Remember record {i}.' for i in range(300))
unit=e.tokenizer.encode(text,add_special_tokens=False)
@torch.no_grad()
def main():
 _,cache=e._prefill(unit[:65])
 for tok in unit[65:321]:e._decode_step(tok,cache)
 ref=reference_logits(e,unit[:321]);out=cache['logits'];rows={'cached':comparison(out,ref,atol=1e-4,rtol=1e-4)}
 for extra in [1,4,16]:
  other=reference_logits(e,unit[:321],extra_pages=extra)
  rows[f'padding_{extra}']=comparison(other,ref,atol=1e-4,rtol=1e-4)
 for chunk in [64,32,1]:
  for b in e.model.blocks:
   if hasattr(b.attn,'base'):b.attn.base.mem.chunk=chunk
  other=reference_logits(e,unit[:321])
  rows[f'memory_chunk_{chunk}']=comparison(other,ref,atol=1e-4,rtol=1e-4)
 print(json.dumps(rows,indent=2),flush=True)
 Path('benchmarks/logs/foveal_verified/fp32_outlier_controls.json').write_text(json.dumps(rows,indent=2)+'\n')
main()
e.close()
